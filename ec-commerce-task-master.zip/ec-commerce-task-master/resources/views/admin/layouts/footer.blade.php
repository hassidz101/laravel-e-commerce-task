<div class="overlay toggle-icon"></div>
<a href="javaScript:void(0);" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
<footer class="page-footer">
	<p class="mb-0">Copyright © {{date('Y')}} Develop by Organization</p>
</footer>
